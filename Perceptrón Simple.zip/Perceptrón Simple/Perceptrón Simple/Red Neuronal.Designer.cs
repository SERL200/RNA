﻿
namespace Perceptrón_Simple
{
    partial class Red_Neuronal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Red_Neuronal));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Tabla = new System.Windows.Forms.DataGridView();
            this.Salir = new System.Windows.Forms.PictureBox();
            this.Minimizar = new System.Windows.Forms.PictureBox();
            this.Entrenar = new System.Windows.Forms.Button();
            this.W0 = new System.Windows.Forms.TextBox();
            this.W1 = new System.Windows.Forms.TextBox();
            this.W2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Clasificar = new System.Windows.Forms.Button();
            this.X1 = new System.Windows.Forms.TextBox();
            this.X2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Punto_Color = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Cl = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Es0 = new System.Windows.Forms.TextBox();
            this.Es1 = new System.Windows.Forms.TextBox();
            this.Es2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Aleatorio = new System.Windows.Forms.Button();
            this.Iteraciones = new System.Windows.Forms.DataGridView();
            this.Reiniciar = new System.Windows.Forms.Button();
            this.TA = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Tabla)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Salir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Iteraciones)).BeginInit();
            this.SuspendLayout();
            // 
            // Tabla
            // 
            this.Tabla.AllowUserToAddRows = false;
            this.Tabla.AllowUserToDeleteRows = false;
            this.Tabla.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Tabla.BackgroundColor = System.Drawing.Color.White;
            this.Tabla.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Tabla.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Tabla.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Tabla.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.Tabla.ColumnHeadersHeight = 22;
            this.Tabla.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.Tabla.EnableHeadersVisualStyles = false;
            this.Tabla.Location = new System.Drawing.Point(27, 49);
            this.Tabla.MultiSelect = false;
            this.Tabla.Name = "Tabla";
            this.Tabla.ReadOnly = true;
            this.Tabla.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Tabla.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.Tabla.RowHeadersWidth = 60;
            this.Tabla.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Tabla.Size = new System.Drawing.Size(394, 293);
            this.Tabla.TabIndex = 0;
            // 
            // Salir
            // 
            this.Salir.BackColor = System.Drawing.Color.MistyRose;
            this.Salir.Image = ((System.Drawing.Image)(resources.GetObject("Salir.Image")));
            this.Salir.Location = new System.Drawing.Point(924, 0);
            this.Salir.Name = "Salir";
            this.Salir.Size = new System.Drawing.Size(25, 25);
            this.Salir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Salir.TabIndex = 1;
            this.Salir.TabStop = false;
            this.Salir.Click += new System.EventHandler(this.Salir_Click);
            this.Salir.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Salir_MouseDown);
            this.Salir.MouseEnter += new System.EventHandler(this.Salir_MouseEnter);
            this.Salir.MouseLeave += new System.EventHandler(this.Salir_MouseLeave);
            // 
            // Minimizar
            // 
            this.Minimizar.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.Minimizar.Image = ((System.Drawing.Image)(resources.GetObject("Minimizar.Image")));
            this.Minimizar.Location = new System.Drawing.Point(897, 0);
            this.Minimizar.Name = "Minimizar";
            this.Minimizar.Size = new System.Drawing.Size(25, 25);
            this.Minimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Minimizar.TabIndex = 1;
            this.Minimizar.TabStop = false;
            this.Minimizar.Click += new System.EventHandler(this.Minimizar_Click);
            this.Minimizar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Minimizar_MouseDown);
            this.Minimizar.MouseEnter += new System.EventHandler(this.Minimizar_MouseEnter);
            this.Minimizar.MouseLeave += new System.EventHandler(this.Minimizar_MouseLeave);
            // 
            // Entrenar
            // 
            this.Entrenar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Entrenar.Location = new System.Drawing.Point(183, 405);
            this.Entrenar.Name = "Entrenar";
            this.Entrenar.Size = new System.Drawing.Size(76, 70);
            this.Entrenar.TabIndex = 2;
            this.Entrenar.Text = "Entrenar";
            this.Entrenar.UseVisualStyleBackColor = true;
            this.Entrenar.Click += new System.EventHandler(this.Entrenar_Click);
            // 
            // W0
            // 
            this.W0.Location = new System.Drawing.Point(321, 407);
            this.W0.Name = "W0";
            this.W0.ReadOnly = true;
            this.W0.Size = new System.Drawing.Size(100, 20);
            this.W0.TabIndex = 3;
            // 
            // W1
            // 
            this.W1.Location = new System.Drawing.Point(321, 433);
            this.W1.Name = "W1";
            this.W1.ReadOnly = true;
            this.W1.Size = new System.Drawing.Size(100, 20);
            this.W1.TabIndex = 3;
            // 
            // W2
            // 
            this.W2.Location = new System.Drawing.Point(321, 459);
            this.W2.Name = "W2";
            this.W2.ReadOnly = true;
            this.W2.Size = new System.Drawing.Size(100, 20);
            this.W2.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(288, 410);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = " W0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(291, 436);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "W1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(291, 462);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "W2";
            // 
            // Clasificar
            // 
            this.Clasificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clasificar.Location = new System.Drawing.Point(663, 373);
            this.Clasificar.Name = "Clasificar";
            this.Clasificar.Size = new System.Drawing.Size(141, 37);
            this.Clasificar.TabIndex = 2;
            this.Clasificar.Text = "Clasificar Punto";
            this.Clasificar.UseVisualStyleBackColor = true;
            this.Clasificar.Click += new System.EventHandler(this.Clasificar_Click);
            // 
            // X1
            // 
            this.X1.Location = new System.Drawing.Point(663, 345);
            this.X1.Name = "X1";
            this.X1.Size = new System.Drawing.Size(55, 20);
            this.X1.TabIndex = 3;
            this.X1.Text = "5";
            // 
            // X2
            // 
            this.X2.Location = new System.Drawing.Point(749, 345);
            this.X2.Name = "X2";
            this.X2.Size = new System.Drawing.Size(55, 20);
            this.X2.TabIndex = 3;
            this.X2.Text = "3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(643, 348);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "X1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(729, 348);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "X2";
            // 
            // Punto_Color
            // 
            this.Punto_Color.BackColor = System.Drawing.Color.White;
            this.Punto_Color.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Punto_Color.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Punto_Color.Location = new System.Drawing.Point(706, 416);
            this.Punto_Color.Multiline = true;
            this.Punto_Color.Name = "Punto_Color";
            this.Punto_Color.ReadOnly = true;
            this.Punto_Color.Size = new System.Drawing.Size(98, 20);
            this.Punto_Color.TabIndex = 3;
            this.Punto_Color.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(24, 352);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Pesos a entrenar;";
            // 
            // Cl
            // 
            this.Cl.Location = new System.Drawing.Point(545, 344);
            this.Cl.Name = "Cl";
            this.Cl.ReadOnly = true;
            this.Cl.Size = new System.Drawing.Size(53, 20);
            this.Cl.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(494, 348);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = " Ciclos";
            // 
            // Es0
            // 
            this.Es0.Location = new System.Drawing.Point(137, 348);
            this.Es0.Name = "Es0";
            this.Es0.Size = new System.Drawing.Size(55, 20);
            this.Es0.TabIndex = 3;
            this.Es0.Text = "1";
            // 
            // Es1
            // 
            this.Es1.Location = new System.Drawing.Point(198, 348);
            this.Es1.Name = "Es1";
            this.Es1.Size = new System.Drawing.Size(55, 20);
            this.Es1.TabIndex = 3;
            this.Es1.Text = "1";
            // 
            // Es2
            // 
            this.Es2.Location = new System.Drawing.Point(259, 348);
            this.Es2.Name = "Es2";
            this.Es2.Size = new System.Drawing.Size(55, 20);
            this.Es2.TabIndex = 3;
            this.Es2.Text = "1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(158, 371);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(21, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "w0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(275, 371);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "w2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(215, 371);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "w1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(660, 420);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Color;";
            // 
            // Aleatorio
            // 
            this.Aleatorio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aleatorio.Location = new System.Drawing.Point(326, 348);
            this.Aleatorio.Name = "Aleatorio";
            this.Aleatorio.Size = new System.Drawing.Size(95, 20);
            this.Aleatorio.TabIndex = 2;
            this.Aleatorio.Text = "Aleatorio";
            this.Aleatorio.UseVisualStyleBackColor = true;
            this.Aleatorio.Click += new System.EventHandler(this.Aleatorio_Click);
            // 
            // Iteraciones
            // 
            this.Iteraciones.AllowUserToAddRows = false;
            this.Iteraciones.AllowUserToDeleteRows = false;
            this.Iteraciones.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.Iteraciones.BackgroundColor = System.Drawing.Color.White;
            this.Iteraciones.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Iteraciones.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Iteraciones.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.LimeGreen;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Iteraciones.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.Iteraciones.ColumnHeadersHeight = 22;
            this.Iteraciones.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.Iteraciones.EnableHeadersVisualStyles = false;
            this.Iteraciones.Location = new System.Drawing.Point(443, 49);
            this.Iteraciones.MultiSelect = false;
            this.Iteraciones.Name = "Iteraciones";
            this.Iteraciones.ReadOnly = true;
            this.Iteraciones.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Iteraciones.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.Iteraciones.RowHeadersWidth = 20;
            this.Iteraciones.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Iteraciones.Size = new System.Drawing.Size(361, 293);
            this.Iteraciones.TabIndex = 0;
            // 
            // Reiniciar
            // 
            this.Reiniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reiniciar.Location = new System.Drawing.Point(826, 49);
            this.Reiniciar.Name = "Reiniciar";
            this.Reiniciar.Size = new System.Drawing.Size(117, 53);
            this.Reiniciar.TabIndex = 5;
            this.Reiniciar.Text = "Reiniciar Entrenamiento";
            this.Reiniciar.UseVisualStyleBackColor = true;
            this.Reiniciar.Click += new System.EventHandler(this.Reiniciar_Click);
            // 
            // TA
            // 
            this.TA.Location = new System.Drawing.Point(118, 431);
            this.TA.Name = "TA";
            this.TA.Size = new System.Drawing.Size(43, 20);
            this.TA.TabIndex = 6;
            this.TA.Text = "0,01";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(35, 423);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 26);
            this.label12.TabIndex = 4;
            this.label12.Text = "Tasa de \r\nAprendizaje:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Red_Neuronal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(955, 496);
            this.Controls.Add(this.TA);
            this.Controls.Add(this.Reiniciar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.X2);
            this.Controls.Add(this.Punto_Color);
            this.Controls.Add(this.Es2);
            this.Controls.Add(this.Es1);
            this.Controls.Add(this.Es0);
            this.Controls.Add(this.X1);
            this.Controls.Add(this.Cl);
            this.Controls.Add(this.W2);
            this.Controls.Add(this.W1);
            this.Controls.Add(this.W0);
            this.Controls.Add(this.Clasificar);
            this.Controls.Add(this.Aleatorio);
            this.Controls.Add(this.Entrenar);
            this.Controls.Add(this.Minimizar);
            this.Controls.Add(this.Salir);
            this.Controls.Add(this.Iteraciones);
            this.Controls.Add(this.Tabla);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Red_Neuronal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " W1";
            this.Load += new System.EventHandler(this.Red_Neuronal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Tabla)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Salir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Minimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Iteraciones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Tabla;
        private System.Windows.Forms.PictureBox Salir;
        private System.Windows.Forms.PictureBox Minimizar;
        private System.Windows.Forms.Button Entrenar;
        private System.Windows.Forms.TextBox W0;
        private System.Windows.Forms.TextBox W1;
        private System.Windows.Forms.TextBox W2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Clasificar;
        private System.Windows.Forms.TextBox X1;
        private System.Windows.Forms.TextBox X2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Cl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Es0;
        private System.Windows.Forms.TextBox Es1;
        private System.Windows.Forms.TextBox Es2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button Aleatorio;
        private System.Windows.Forms.DataGridView Iteraciones;
        private System.Windows.Forms.TextBox Punto_Color;
        private System.Windows.Forms.Button Reiniciar;
        private System.Windows.Forms.TextBox TA;
        private System.Windows.Forms.Label label12;
    }
}