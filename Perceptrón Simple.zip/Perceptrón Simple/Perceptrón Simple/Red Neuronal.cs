﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Perceptrón_Simple
{
    public partial class Red_Neuronal : Form
    {
        public Red_Neuronal()
        {
            InitializeComponent();
        }

        // Creacion de las Matrices y Vectores

        int[,] Entradas = new int[3, 11];
        int[] Salidas = new int[11];
        double[] Estimulos = new double[3];
        float Aprendizaje;
        
        


        private void Red_Neuronal_Load(object sender, EventArgs e)
        {
            Clasificar.Enabled = false;
            Reiniciar.Enabled = false;
            const int I = -1;


            //Creacion de Tablas de Visualizacion de datos

            Tabla.Columns.Add("X0", "Independiente");
            Tabla.Columns.Add("X1", "Entrada 1");
            Tabla.Columns.Add("X2", "Entrada 2");
            Tabla.Columns.Add("Y", "Salida");

            Iteraciones.Columns.Add("s", "Salida de Red");
            Iteraciones.Columns.Add("Error", "Error");
            Iteraciones.Columns.Add("Est0", "W0");
            Iteraciones.Columns.Add("dW0", "dW0");
            Iteraciones.Columns.Add("Est1", "W1");
            Iteraciones.Columns.Add("dW1", "dW1");
            Iteraciones.Columns.Add("Est2", "W2");
            Iteraciones.Columns.Add("dW2", "dW2");
           

            //      Carga de datos de las Entradas y Salidas Esperadas 
            //      En la Primera Tabla de datos (Conjunto de Puntos y Colores)


            //              x0

            for (int x0=0; x0 < 11; x0++)
            {
                Tabla.Rows.Add();
                Tabla.Rows[x0].Cells[0].Value = I;
                Tabla.Rows[x0].Cells[0].Style.BackColor = Color.Beige;
            }

            //                    x1                     //                    x2                    //                 y                   //
            Tabla.Rows[0].Cells[1].Value = 1;               Tabla.Rows[0].Cells[2].Value = 0;           Tabla.Rows[0].Cells[3].Value = -1;
            Tabla.Rows[1].Cells[1].Value = 1;               Tabla.Rows[1].Cells[2].Value = 1;           Tabla.Rows[1].Cells[3].Value = -1;
            Tabla.Rows[2].Cells[1].Value = 1;               Tabla.Rows[2].Cells[2].Value = 2;           Tabla.Rows[2].Cells[3].Value = 1;
            Tabla.Rows[3].Cells[1].Value = 1;               Tabla.Rows[3].Cells[2].Value = 4;           Tabla.Rows[3].Cells[3].Value = 1;
            Tabla.Rows[4].Cells[1].Value = 2;               Tabla.Rows[4].Cells[2].Value = 1;           Tabla.Rows[4].Cells[3].Value = -1;
            Tabla.Rows[5].Cells[1].Value = 2;               Tabla.Rows[5].Cells[2].Value = 2;           Tabla.Rows[5].Cells[3].Value = -1;
            Tabla.Rows[6].Cells[1].Value = 2;               Tabla.Rows[6].Cells[2].Value = 3;           Tabla.Rows[6].Cells[3].Value = 1;
            Tabla.Rows[7].Cells[1].Value = 2;               Tabla.Rows[7].Cells[2].Value = 4;           Tabla.Rows[7].Cells[3].Value = 1;
            Tabla.Rows[8].Cells[1].Value = 3;               Tabla.Rows[8].Cells[2].Value = 4;           Tabla.Rows[8].Cells[3].Value = 1;
            Tabla.Rows[9].Cells[1].Value = 4;               Tabla.Rows[9].Cells[2].Value = 2;           Tabla.Rows[9].Cells[3].Value = -1;
            Tabla.Rows[10].Cells[1].Value = 4;              Tabla.Rows[10].Cells[2].Value = 4;          Tabla.Rows[10].Cells[3].Value = 1;


            foreach (DataGridViewRow row in Tabla.Rows)
            {
                row.HeaderCell.Value = "P" + Convert.ToString(row.Index + 1);
            }

            for (int y = 0; y < 11; y++)
            {
                if (Convert.ToInt32(Tabla.Rows[y].Cells[3].Value) == 1)
                {
                    Tabla.Rows[y].Cells[3].Style.BackColor = Color.DeepSkyBlue; 
                }
                else 
                {
                    Tabla.Rows[y].Cells[3].Style.BackColor = Color.OrangeRed;
                }
            }


            //Carga de Datos de las Tablas a los Vectores Y Matrices de Entrenamiento 

            Cargar_Entradas(Entradas);
            Cargar_Salidas(Salidas);
            Cargar_Estimulos(Estimulos);
            

        }



        //          Boton de Entrenamiento

        private void Entrenar_Click(object sender, EventArgs e)
        {
            
            bool er;
            int Error;
            int Salida_Red;
            int contar = 0;
            int ciclos = 0;
            double[] dW = new double[3];

            Aprendizaje = float.Parse(TA.Text);
            Estimulos[0] = Convert.ToDouble(Es0.Text);
            Estimulos[1] = Convert.ToDouble(Es1.Text);
            Estimulos[2] = Convert.ToDouble(Es2.Text);

            

            do
            {
                ciclos += 1;
                Error = 0;
                er = false;

                for (int T = 0; T < 11; T++)
                {

                    Salida_Red = Signo(T);
                    Error += Salidas[T] - Salida_Red;
                    if (Error != 0)
                    {
                        er = true;
                    }

                    for (int i = 0; i < 3; i++)
                    {
                        dW[i] = Aprendizaje * Entradas[i, T] * (Salidas[T] - Salida_Red);
                        Estimulos[i] += dW[i];
                        
                    }
                    Mostrar_Iteracion(Salida_Red, Error, Estimulos, dW, contar);
                    contar++;
                }
                Iteraciones.Rows.Add();
                Iteraciones.Rows[contar].Cells[0].Value = "Ciclo " + (ciclos + 1).ToString();
                contar++;


            }
            while (er == true);



            Cl.Text = ciclos.ToString();
            W0.Text = Estimulos[0].ToString();
            W1.Text = Estimulos[1].ToString();
            W2.Text = Estimulos[2].ToString();
            Clasificar.Enabled = true;
            Reiniciar.Enabled = true;
            Entrenar.Enabled = false;
        }
        
        private int Signo(int T)
        {
            double S;
            int s;
            S = (Estimulos[2] * Entradas[2, T]) + (Estimulos[1] * Entradas[1, T]) + (Estimulos[0] * -1);
            if (S >= 0)
            { s = 1; }
            else
            { s = -1; }

            return s;
        }

        // Mostrar Proceso de Entrenamiento en la Segunda Tabla de datos
        private void Mostrar_Iteracion(int s, int Error, double[] Estimulos, double[] dW, int i)
        {
            
            Iteraciones.Rows.Add();
            Iteraciones.Rows[i].Cells[0].Value = s;
            if (s >= 0)
            { Iteraciones.Rows[i].Cells[0].Style.BackColor = Color.DarkBlue; }
            else 
            { Iteraciones.Rows[i].Cells[0].Style.BackColor = Color.Crimson; }
            Iteraciones.Rows[i].Cells[1].Value = Error;
            Iteraciones.Rows[i].Cells[2].Value = Estimulos[0];
            Iteraciones.Rows[i].Cells[3].Value = dW[0];
            Iteraciones.Rows[i].Cells[4].Value = Estimulos[1];
            Iteraciones.Rows[i].Cells[5].Value = dW[1];
            Iteraciones.Rows[i].Cells[6].Value = Estimulos[2];
            Iteraciones.Rows[i].Cells[7].Value = dW[2];

            

        }

        //Boton que muestra el color de un Punto cualquiera segun nuestra Red
        private void Clasificar_Click(object sender, EventArgs e)
        {
            int x1, x2;
            double Signo;

            x1 = Convert.ToInt32(X1.Text);
            x2 = Convert.ToInt32(X2.Text);

            Signo = (Estimulos[2] * x2) + (Estimulos[1] * x1) + (Estimulos[0] * -1);

            if (Signo >= 0)
            {
                Punto_Color.BackColor = Color.DeepSkyBlue;
                Punto_Color.Text = "AZUL";
            }
            else
            {
                Punto_Color.BackColor = Color.OrangeRed;
                Punto_Color.ForeColor = Color.White;
                Punto_Color.Text = "ROJO";
            }

        }

        //Boton de Reinicio de Entrenamiento
        private void Reiniciar_Click(object sender, EventArgs e)
        {
            Cargar_Estimulos(Estimulos);

            Es0.Text = 1.ToString();
            Es1.Text = 1.ToString();
            Es2.Text = 1.ToString();

            TA.Text = Aprendizaje.ToString();
            W0.Text = "";
            W1.Text = "";
            W2.Text = "";
            Cl.Text = "";
            X1.Text = 5.ToString();
            X2.Text = 3.ToString();
            Punto_Color.Text = "";
            Punto_Color.BackColor = Color.White;
            Clasificar.Enabled = false;
            Reiniciar.Enabled = false;
            Entrenar.Enabled = true;

            Iteraciones.Rows.Clear();
        }


        //Boton para generar valores iniciales aleatorios

        private void Aleatorio_Click(object sender, EventArgs e)
        {
            Random R = new Random();
            Es0.Text = (1.0 + R.NextDouble()).ToString();
            Es1.Text = (1.0 + R.NextDouble()).ToString();
            Es2.Text = (1.0 + R.NextDouble()).ToString();
        }


















































        private void Cargar_Entradas(int[,] Matriz)
        {

            for (int j = 0; j < 11; j++)
            {


                for (int i = 0; i < 3; i++)
                {

                    Matriz[i, j] = Convert.ToInt32(Tabla.Rows[j].Cells[i].Value);

                }

            }


        }

        private void Cargar_Salidas(int[] Vector)
        {
            int i = 0;

            foreach (DataGridViewRow Row in Tabla.Rows)
            {

                Vector[i] = Convert.ToInt32(Row.Cells[3].Value);
                i++;

            }

        }

        private void Cargar_Estimulos(double[] Vector)
        {
            int i = 0;

            foreach (double w in Vector)
            {

                Vector[i] = 1;
                i++;

            }



        }


        private void Salir_MouseEnter(object sender, EventArgs e)
        {
            Salir.BackColor = Color.Red;
        }

        private void Salir_MouseDown(object sender, MouseEventArgs e)
        {
            Salir.BackColor = Color.Crimson;
        }

        private void Salir_MouseLeave(object sender, EventArgs e)
        {
            Salir.BackColor = Color.MistyRose;
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            
            
            DialogResult D = MessageBox.Show("Salir?","",MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            
            
            if (D == DialogResult.OK)
            {

                Application.Exit();

            }
        }

  

        private void Minimizar_MouseEnter(object sender, EventArgs e)
        {
            Minimizar.BackColor = Color.Yellow;
        }

        private void Minimizar_MouseDown(object sender, MouseEventArgs e)
        {
            Minimizar.BackColor = Color.Gold;
        }

        private void Minimizar_MouseLeave(object sender, EventArgs e)
        {
            Minimizar.BackColor = Color.LightGoldenrodYellow;
        }

        private void Minimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

    }





}
